window.__PANEL_CONFIG__ = {
    NUM_INFO_API: "https://rohit-all-in-one-api.vercel.app/api/num-info",
    NUM_INFO_KEY: "1Month"
};
