/**
 * build.js — Obfuscation Build Script for Mythos Panel
 * 
 * Extracts the JS from the source HTML, injects environment variables,
 * obfuscates it with medium-high settings, and produces a clean index.html.
 */

const fs = require('fs');
const JavaScriptObfuscator = require('javascript-obfuscator');
require('dotenv').config();

const SOURCE = 'Profex panel src v5.html';
const OUTPUT = 'index.html';

console.log('[1/4] Reading source HTML...');
let html = fs.readFileSync(SOURCE, 'utf8');

// Inject environment variables
console.log('[2/4] Injecting environment variables...');
const botToken = process.env.TELEGRAM_BOT_TOKEN || "YOUR_BOT_TOKEN_HERE";
const chatId = process.env.TELEGRAM_CHAT_ID || "YOUR_CHAT_ID_HERE";

html = html.replace(/process\.env\.TELEGRAM_BOT_TOKEN/g, `"${botToken}"`);
html = html.replace(/process\.env\.TELEGRAM_CHAT_ID/g, `"${chatId}"`);

// Find the script boundaries
const scriptOpenTag = '    <script>';
const scriptCloseTag = '    </script>';
const scriptStart = html.indexOf(scriptOpenTag);
const scriptEnd = html.indexOf(scriptCloseTag, scriptStart);

if (scriptStart === -1 || scriptEnd === -1) {
    console.error('Could not find <script> boundaries!');
    process.exit(1);
}

const beforeScript = html.substring(0, scriptStart);
const jsCode = html.substring(scriptStart + scriptOpenTag.length, scriptEnd);
const afterScript = html.substring(scriptEnd + scriptCloseTag.length);

console.log(`[3/4] Extracted JS code (${(jsCode.length / 1024).toFixed(0)} KB). Obfuscating...`);
console.log('       This may take 1-3 minutes, please wait...');

const obfuscationResult = JavaScriptObfuscator.obfuscate(jsCode, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.5,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.3,
    debugProtection: false,
    disableConsoleOutput: false,
    identifierNamesGenerator: 'hexadecimal',
    log: false,
    numbersToExpressions: true,
    renameGlobals: false,
    selfDefending: false,
    simplify: true,
    splitStrings: true,
    splitStringsChunkLength: 8,
    stringArray: true,
    stringArrayCallsTransform: true,
    stringArrayCallsTransformThreshold: 0.5,
    stringArrayEncoding: ['base64'],
    stringArrayIndexShift: true,
    stringArrayRotate: true,
    stringArrayShuffle: true,
    stringArrayWrappersCount: 2,
    stringArrayWrappersChainedCalls: true,
    stringArrayWrappersParametersMaxCount: 4,
    stringArrayWrappersType: 'function',
    stringArrayThreshold: 0.75,
    target: 'browser',
    transformObjectKeys: true,
    unicodeEscapeSequence: false
});

const obfuscatedJs = obfuscationResult.getObfuscatedCode();
console.log(`[4/4] Obfuscation complete. Building HTML...`);

const configScriptTag = '    <script src="config.js"></script>\n';
const finalHtml = beforeScript + configScriptTag + '    <script>' + obfuscatedJs + '    </script>' + afterScript;

fs.writeFileSync(OUTPUT, finalHtml, 'utf8');
console.log(`[✓] Written to ${OUTPUT} (${(finalHtml.length / 1024 / 1024).toFixed(2)} MB)`);
